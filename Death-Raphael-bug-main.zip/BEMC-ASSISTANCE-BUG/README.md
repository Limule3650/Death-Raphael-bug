**ASSISTANCE-BUG MULTI DEVICE WHATSAPP BOT**
  </p>
<p align="center">
  <a href="https://whatsapp.com/channel/0029Vafhjw0IXnlonRAQMM2l">
    <img alt=Support height="400" src="https://telegra.ph/file/7c4fb86c9575d9c0f4357.jpg"
    <p align="center">
  <a href="#"><img src="http://readme-typing-svg.herokuapp.com?color=ff00ab&center=true&vCenter=true&multiline=false&lines=BASE+BY+DGXEON." alt="">
</p>
<h1 align="center"> ASSISTANCE-BUG </h1>
</h1>
<p align="center"> Here's the channel support 
<p align="center"> 
 <a href="https://chat.whatsapp.com/C5QLzSAmXER7wBGerwVWrF" target="_blank">
    <img alt="whatsapp channel" src="https://img.shields.io/badge/ Whatsapp Support channel -25D366?style=for-the-badge&logo=whatsapp&logoColor=red" />
 </a>   

 
### **ALERTE ⚠️**
please add the cred.json file to the session folder

 ### ℹ️ **ABOUT DEATH-RAPHAEL-BUG**
 Introducing ASSISTANCE-BUG , It is designed to bring a whole new level of excitement to your boring WhatsApp use.hope it might be helpful to all loosen hope we feel delightful to save you release your feedback and share our chuddy buddy </p>


`Ｆ•Ｅ•Ａ•Ｔ•Ｕ•Ｒ•Ｅ•Ｓ`


***◉ Multi-Device Support  
◉ AI Photo Enhancement  
◉ Downloader Commands  
◉ Hidden NSFW Commands   
◉ Anime Commands   
◉ Various Games  
◉ Audio/Video Editor Commands                   
◉ Others......***


1. ***Star⭐ The Repository Must***
          <br>
          
2.  **Fork My Repository**
          <br>
<a href='https://github.com/Limule3650/Death-Raphael-bug/fork' target="_blank"><img alt='Fork repo' src='https://img.shields.io/badge/Fork This Repo-black?style=for-the-badge&logo=git&logoColor=Blue'/></a>
      <br> 
     
 Get pairing code.
    <br>
<a href='https://death-raphael.onrender.com/' target="_blank"><img alt='PAIR CODE' src='https://img.shields.io/badge/Scan_qr-100000?style=for-the-badge&logo=scan&logoColor=white&labelColor=red&color=red'/></a>

  
***[𝗔𝗨𝗧𝗛𝗢𝗥 𝗢𝗙 𝗤𝗥 𝗖𝗢𝗗𝗘](https://github.com/DarkMakerofc)***
  

<details close>
<summary>click here to choose your deployment platform </summary>
 
<br>  


### `DEPLOY TO REPLIT`

1. If You don't have an account in Replit. Create a account.
    <br>
<a href='https://replit.com/signup' target="_blank"><img alt='Heroku' src='https://img.shields.io/badge/-Create-black?style=for-the-badge&logo=replit&logoColor=white'/></a>

2. Now Deploy
    <br>
    <a href='https://repl.it/github/Limule3650/Death-Raphael-bug ' target="_blank"><img alt='DEPLOY' src='https://img.shields.io/badge/-DEPLOY-black?style=for-the-badge&logo=replit&logoColor=white'/></a>

### DEPLOY TO CODESPACE

3. If You don't have a account in Codespace. Create a account.
    <br>
<a href='https://github.com/login?return_to=https%3A%2F%2Fgithub.com%2Fcodespaces' target="_blank"><img alt='Codespaces' src='https://img.shields.io/badge/CREATE-h?color=black&style=for-the-badge&logo=visualstudiocode' width="96.35" height="28"/></a></p>

4. Now Deploy
    <br>
<a href='https://github.com/codespaces/new' target="_blank"><img alt='DEPLOY' src='https://img.shields.io/badge/DEPLOY -h?color=black&style=for-the-badge&logo=visualstudiocode' width="96.35" height="28"/></a></p>

#### DEPLOY TO HEROKU 

1. If You don't have a account in Heroku. Create a account.
    <br>
<a href='https://signup.heroku.com/' target="_blank"><img alt='Heroku' src='https://img.shields.io/badge/-Create-black?style=for-the-badge&logo=heroku&logoColor=white'/></a>

2. Now Deploy
    <br>
 Not yet available 

#### DEPLOY TO RAILWAY

7. If You don't have a account in Railway. Create a account.
    <br>
<a href='https://railway.app/login' target="_blank"><img alt='Railway' src='https://img.shields.io/badge/CREATE-h?color=black&style=for-the-badge&logo=railway' width="96.35" height="28"/></a></p>

8. Now Deploy
    <br>
<a href='https://railway.app/new' target="_blank"><img alt='DEPLOY' src='https://img.shields.io/badge/DEPLOY -h?color=black&style=for-the-badge&logo=railway' width="96.35" height="28"/></a></p>

</br>
 

# Termux Deployment
```
termux-setup-storage
```
```
apt update
```
```
apt upgrade
```
```
pkg update && pkg upgrade
```
```
pkg install bash
```
```
pkg install libwebp
```
```
pkg install git -y
```
```
pkg install nodejs -y
```
```
pkg install ffmpeg -y 
```
```
pkg install wget
```
```
pkg install yarn
```
```
git clone (copy and paste your forked repo link not mine to save changes your changes) 
```
```
cd Death-Raphael-bug
```
```
yarn install
```
```
npm start
```

<a><img src='https://i.imgur.com/LyHic3i.gif'/></a><a><img src='https://i.imgur.com/LyHic3i.gif'/></a>
- If you want Command For 24/7 (might no work) 
```js
npm i -g forever && forever index.js && forever save && forever logs
```
<br>

<a><img src='https://i.imgur.com/LyHic3i.gif'/></a><a><img src='https://i.imgur.com/LyHic3i.gif'/></a>
<br>
<h2 align="center">  Windows Cmd & Vs  </h2>

- [Download ffmpeg](https://ffmpeg.org/download.html#build-windows) and set the path
- [Download wget](https://eternallybored.org/misc/wget/releases/) and set the path
- [Download Node.js](https://nodejs.org/en/download/)
- [Download Git](https://git-scm.com/downloads)
- [Download Libwebp](https://developers.google.com/speed/webp/download)

```cmd
> git clone https://github.com/Limule3650/Death-Raphael-bug.git
```
```
> cd Death-Raphael-bug
```
```
> yarn install
```
```
> npm start
```
<a><img src='https://i.imgur.com/LyHic3i.gif'/></a><a><img src='https://i.imgur.com/LyHic3i.gif'/></a>

## ```Connect With Me```<img src="https://github.com/0xAbdulKhalid/0xAbdulKhalid/raw/main/assets/mdImages/handshake.gif" width ="80"></h1> 

##
- ***Star ⭐ My Repo If You Like  DEATH RAPHAEL-BUG.***

##

### `𝘛𝘩𝘢𝘯𝘬𝘴 𝘛𝘰`
- ***Team sasaki for collaboration and Everyone***
- ***Who Helped Me***
- ***Who Uses This Bot And Supports Me***
## ```𝘓𝘦𝘨𝘢𝘭 𝘋𝘪𝘴𝘤𝘭𝘢𝘪𝘮𝘦𝘳```

- *`I will only Assist You in Bot Deployment and Hosting, Not in Bot Development`*
- *`if you modify without giving me credit i will report your github account for vawulation policy`*
- *`This Bot is For Fun and Educational Purpose, I will not Responsible If You Spam and And Got Banned`*


- ***Credit : [DGXeon](https://github.com/DGXeon) for base code***

- ***Credit : [TOGE](https://github.com/toge012345) for temporary qr and pairing code***

## Note that i have not yet finished session id so we will use for [TOGE-BUG-BOT] thanks for understanding ##
